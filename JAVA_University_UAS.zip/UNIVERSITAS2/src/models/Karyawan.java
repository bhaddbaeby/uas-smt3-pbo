package models;

import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Karyawan implements Model {
    private int id;
    private String namaLengkap;
    private String posisi;
    private String tanggalTerdaftar;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNamaLengkap() {
        return namaLengkap;
    }

    public void setNamaLengkap(String namaLengkap) {
        this.namaLengkap = namaLengkap;
    }

    public String getPosisi() {
        return posisi;
    }

    public void setPosisi(String posisi) {
        this.posisi = posisi;
    }

    public String getTanggalTerdaftar() {
        return tanggalTerdaftar;
    }

    public void setTanggalTerdaftar(String getTanggalTerdaftar) {
        this.tanggalTerdaftar = getTanggalTerdaftar;
    }
    
    public static ArrayList<Karyawan> ambilSemua() {
        ArrayList<Karyawan> dataKaryawan = new ArrayList<Karyawan>();
        
        try {
            Karyawan k = new Karyawan();
            
            Statement stmt = k.db.koneksi().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM karyawan");
            
            while (rs.next()) {
                Karyawan karyawan = new Karyawan();
                karyawan.setId(rs.getInt("id"));
                karyawan.setNamaLengkap(rs.getString("nama_lengkap"));
                karyawan.setPosisi(rs.getString("posisi"));
                karyawan.setTanggalTerdaftar(rs.getDate("tanggal").toString());
                dataKaryawan.add(karyawan);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Telah terjadi kesalahan, silakan coba lagi\n" + e.getMessage());
        }
        
        return dataKaryawan;
    }
    
    public static ArrayList<Karyawan> ambilSemua(String kataKunci) {
        ArrayList<Karyawan> dataKaryawan = new ArrayList<Karyawan>();
        
        try {
            PreparedStatement stmt = new Karyawan().db.koneksi().prepareStatement("SELECT * FROM karyawan WHERE nama_lengkap LIKE ? OR posisi LIKE ?");
            stmt.setString(1, "%" + kataKunci + "%");
            stmt.setString(2, "%" + kataKunci + "%");
            
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Karyawan karyawan = new Karyawan();
                karyawan.setId(rs.getInt("id"));
                karyawan.setNamaLengkap(rs.getString("nama_lengkap"));
                karyawan.setPosisi(rs.getString("posisi"));
                karyawan.setTanggalTerdaftar(rs.getDate("tanggal").toString());
                dataKaryawan.add(karyawan);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Telah terjadi kesalahan, silakan coba lagi\n" + e.getMessage());
        }
        
        return dataKaryawan;
    }

    @Override
    public boolean simpan() {
        try {
            PreparedStatement stmt = this.db.koneksi().prepareStatement("INSERT INTO `karyawan`(`nama_lengkap`, `posisi`) VALUES (?, ?)");
            stmt.setString(1, this.namaLengkap);
            stmt.setString(2, this.posisi);
            stmt.execute();
            stmt.close();
            
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        
        return false;
    }

    @Override
    public boolean ubah() {
        try {
            PreparedStatement stmt = this.db.koneksi().prepareStatement("UPDATE `karyawan` SET `nama_lengkap`= ?, `posisi`= ? WHERE id = ?");
            stmt.setString(1, this.namaLengkap);
            stmt.setString(2, this.posisi);
            stmt.setInt(3, this.id);
            stmt.execute();
            stmt.close();
            
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        
        return false;
    }

    @Override
    public boolean hapus() {
        try {
            PreparedStatement stmt = this.db.koneksi().prepareStatement("DELETE FROM karyawan WHERE id = ?");
            stmt.setInt(1, this.getId());
            stmt.execute();
            stmt.close();
            
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        
        return false;
    }
}
