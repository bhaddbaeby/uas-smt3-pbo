package models;

import utils.Database;

// interface model untuk class model yang membutuhkan atau melibatkan crud
// contohnya user, karyawan dan pengajar
public interface Model {
    // databasenya
    public Database db = new Database("localhost", "pbo_universitas", "root", "");
    
    // crud
    public boolean simpan(); // simpan == tambah
    public boolean ubah();
    public boolean hapus();
}
