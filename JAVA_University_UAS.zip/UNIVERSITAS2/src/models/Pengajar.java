/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author novil
 */
public class Pengajar implements Model {
    private int id;
    private String namaLengkap;
    private String nip;
    private String mataKuliah;
    private String tanggalTerdaftar;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNamaLengkap() {
        return namaLengkap;
    }

    public void setNamaLengkap(String namaLengkap) {
        this.namaLengkap = namaLengkap;
    }

    public String getNip() {
        return nip;
    }

    public void setNip(String nip) {
        this.nip = nip;
    }

    public String getMataKuliah() {
        return mataKuliah;
    }

    public void setMataKuliah(String mataKuliah) {
        this.mataKuliah = mataKuliah;
    }

    public String getTanggalTerdaftar() {
        return tanggalTerdaftar;
    }

    public void setTanggalTerdaftar(String getTanggalTerdaftar) {
        this.tanggalTerdaftar = getTanggalTerdaftar;
    }
    
    public static ArrayList<Pengajar> ambilSemua() {
        ArrayList<Pengajar> dataPengajar = new ArrayList<Pengajar>();
        
        try {
            Pengajar k = new Pengajar();
            
            Statement stmt = k.db.koneksi().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM pengajar");
            
            while (rs.next()) {
                Pengajar pengajar = new Pengajar();
                pengajar.setId(rs.getInt("id"));
                pengajar.setNamaLengkap(rs.getString("nama_lengkap"));
                pengajar.setNip(rs.getString("nip"));
                pengajar.setMataKuliah(rs.getString("mata_kuliah"));
                pengajar.setTanggalTerdaftar(rs.getDate("tanggal").toString());
                dataPengajar.add(pengajar);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Telah terjadi kesalahan, silakan coba lagi\n" + e.getMessage());
        }
        
        return dataPengajar;
    }
    
    public static ArrayList<Pengajar> ambilSemua(String kataKunci) {
        ArrayList<Pengajar> dataPengajar = new ArrayList<Pengajar>();
        
        try {
            PreparedStatement stmt = new Pengajar().db.koneksi().prepareStatement("SELECT * FROM pengajar WHERE nama_lengkap LIKE ? OR nip LIKE ? OR mata_kuliah LIKE ?");
            stmt.setString(1, "%" + kataKunci + "%");
            stmt.setString(2, "%" + kataKunci + "%");
            stmt.setString(3, "%" + kataKunci + "%");
            
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Pengajar pengajar = new Pengajar();
                pengajar.setId(rs.getInt("id"));
                pengajar.setNamaLengkap(rs.getString("nama_lengkap"));
                pengajar.setNip(rs.getString("nip"));
                pengajar.setMataKuliah(rs.getString("mata_kuliah"));
                pengajar.setTanggalTerdaftar(rs.getDate("tanggal").toString());
                dataPengajar.add(pengajar);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Telah terjadi kesalahan, silakan coba lagi\n" + e.getMessage());
        }
        
        return dataPengajar;
    }

    @Override
    public boolean simpan() {
        try {
            PreparedStatement stmt = this.db.koneksi().prepareStatement("INSERT INTO `pengajar`(`nama_lengkap`, `nip`, `mata_kuliah`) VALUES (?, ?, ?)");
            stmt.setString(1, this.namaLengkap);
            stmt.setString(2, this.nip);
            stmt.setString(3, this.mataKuliah);
            stmt.execute();
            stmt.close();
            
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        
        return false;
    }

    @Override
    public boolean ubah() {
        try {
            PreparedStatement stmt = this.db.koneksi().prepareStatement("UPDATE `pengajar` SET `nama_lengkap`= ?, `nip`= ?, `mata_kuliah` = ? WHERE id = ?");
            stmt.setString(1, this.namaLengkap);
            stmt.setString(2, this.nip);
            stmt.setString(3, this.mataKuliah);
            stmt.setInt(4, this.id);
            stmt.execute();
            stmt.close();
            
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        
        return false;
    }

    @Override
    public boolean hapus() {
        try {
            PreparedStatement stmt = this.db.koneksi().prepareStatement("DELETE FROM pengajar WHERE id = ?");
            stmt.setInt(1, this.getId());
            stmt.execute();
            stmt.close();
            
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        
        return false;
    }
}
