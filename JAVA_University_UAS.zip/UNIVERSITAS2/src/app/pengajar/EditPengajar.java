package app.pengajar;

import app.Home;
import models.Pengajar;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

public class EditPengajar extends javax.swing.JFrame {

    public EditPengajar(Home homeFrame, int idPengajar, String namaLengkap, String nip, String mataKuliah) {
        initComponents();
        
        // arahkan frame ke tengah dan dengan fixed size
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        // dan dispose frame ini ketika di close
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        // set input value lama
        this.idPengajar = idPengajar;
        this.namaLengkapText.setText(namaLengkap);
        this.nipText.setText(nip);
        this.mataKuliahComboBox.setSelectedItem(mataKuliah);
        
        // ambil object frame home agar bisa menggunakan method ambilDataPengajar
        this.homeFrame = homeFrame;
        
        // menutup frame saat menekan tombol Esc
        this.setTutupFrameSaatEscape();
        
        this.namaLengkapText.addActionListener((e) -> this.editPengajar());
        this.nipText.addActionListener((e) -> this.editPengajar());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        editPengajarLabel = new javax.swing.JLabel();
        namaLengkapLabel = new javax.swing.JLabel();
        namaLengkapText = new javax.swing.JTextField();
        nipLabel = new javax.swing.JLabel();
        nipText = new javax.swing.JTextField();
        mataKuliahLabel = new javax.swing.JLabel();
        mataKuliahComboBox = new javax.swing.JComboBox<>();
        editPengajarButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        hapusPengajarButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        editPengajarLabel.setFont(new java.awt.Font("Cambria", 1, 24)); // NOI18N
        editPengajarLabel.setForeground(new java.awt.Color(0, 0, 102));
        editPengajarLabel.setText("EDIT PENGAJAR");

        namaLengkapLabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        namaLengkapLabel.setText("Nama Lengkap");

        namaLengkapText.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 153)));

        nipLabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        nipLabel.setText("NIP");

        nipText.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 153)));

        mataKuliahLabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        mataKuliahLabel.setText("Mata Kuliah");

        mataKuliahComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Interaksi Manusa dan Komputer", "Desain dan Manajemen Jaringan Komputer", "Desain Basis Data" }));
        mataKuliahComboBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 153)));

        editPengajarButton.setBackground(new java.awt.Color(0, 0, 102));
        editPengajarButton.setForeground(new java.awt.Color(255, 255, 255));
        editPengajarButton.setText("Edit");
        editPengajarButton.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        editPengajarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editPengajarButtonActionPerformed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/app/1111.png"))); // NOI18N
        jLabel2.setText("jLabel2");

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/app/111.png"))); // NOI18N
        jLabel4.setText("jLabel4");

        hapusPengajarButton.setBackground(new java.awt.Color(204, 0, 0));
        hapusPengajarButton.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        hapusPengajarButton.setForeground(new java.awt.Color(255, 255, 255));
        hapusPengajarButton.setText("Hapus");
        hapusPengajarButton.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        hapusPengajarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusPengajarButtonActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/app/pengajar/output-onlinepngtools.png"))); // NOI18N
        jLabel1.setText("jLabel1");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(namaLengkapLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(hapusPengajarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(editPengajarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(mataKuliahComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 441, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(mataKuliahLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(namaLengkapText, javax.swing.GroupLayout.PREFERRED_SIZE, 441, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(nipLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(nipText, javax.swing.GroupLayout.PREFERRED_SIZE, 441, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(63, Short.MAX_VALUE))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addComponent(editPengajarLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(editPengajarLabel)
                        .addGap(18, 18, 18))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(38, 38, 38)))
                .addComponent(namaLengkapLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(namaLengkapText, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(nipLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nipText, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(mataKuliahLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(mataKuliahComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(editPengajarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(hapusPengajarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(42, 42, 42)
                .addComponent(jLabel4))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void editPengajarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editPengajarButtonActionPerformed
        this.editPengajar();
    }//GEN-LAST:event_editPengajarButtonActionPerformed

    private void hapusPengajarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusPengajarButtonActionPerformed
        int konfirmasi = JOptionPane.showConfirmDialog(null, "Apakah anda yakin ingin menghapus data ini?");
        if (konfirmasi == 0) {
            Pengajar pengajar = new Pengajar();
            pengajar.setId(this.idPengajar);

            if (pengajar.hapus()) {
                JOptionPane.showMessageDialog(null, "Berhasil menghapus data pengajar");
                this.homeFrame.ambilDataPengajar();
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(null, "Telah terjadi kesalahan, silakan coba lagi");
            }
        }
    }//GEN-LAST:event_hapusPengajarButtonActionPerformed

    public void editPengajar() {
        String namaLengkap = this.namaLengkapText.getText();
        String nip = this.nipText.getText();
        String mataKuliah = this.mataKuliahComboBox.getSelectedItem().toString();
        
        Pengajar pengajarBaru = new Pengajar();
        pengajarBaru.setId(this.idPengajar);
        pengajarBaru.setNamaLengkap(namaLengkap);
        pengajarBaru.setNip(nip);
        pengajarBaru.setMataKuliah(mataKuliah);
        
        if (pengajarBaru.ubah()) {
            JOptionPane.showMessageDialog(null, "Berhasil mengedit data pengajar");
            this.homeFrame.ambilDataPengajar();
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(null, "Telah terjadi kesalahan, silakan coba lagi");
        }
    }
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditPengajar(new Home(), 0, "", "", "").setVisible(true);
            }
        });
    }
    
    // menutup frame saat menekan tombol Esc
    private void setTutupFrameSaatEscape() {
        this.getRootPane()
            .getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
            .put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "Cancel");
        
        EditPengajar self = this;
        this.getRootPane().getActionMap().put("Cancel", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                self.setVisible(false);
                self.dispose();
            }
        });
    }
    
    private int idPengajar;
    private Home homeFrame;

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton editPengajarButton;
    private javax.swing.JLabel editPengajarLabel;
    private javax.swing.JButton hapusPengajarButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JComboBox<String> mataKuliahComboBox;
    private javax.swing.JLabel mataKuliahLabel;
    private javax.swing.JLabel namaLengkapLabel;
    private javax.swing.JTextField namaLengkapText;
    private javax.swing.JLabel nipLabel;
    private javax.swing.JTextField nipText;
    // End of variables declaration//GEN-END:variables
}
