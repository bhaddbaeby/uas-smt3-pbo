/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package app;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;

import app.karyawan.TambahKaryawan;
import app.karyawan.EditKaryawan;
import app.pengajar.TambahPengajar;
import app.pengajar.EditPengajar;

import models.Karyawan;
import models.Pengajar;
import utils.Tanggal;

/**
 *
 * @author novil
 */
public class Home extends javax.swing.JFrame {

    /**
     * Creates new form Home
     */
    public Home() {
        initComponents();
        
        // arahkan frame ke tengah
        this.setSize(800, 500);
        this.setLocationRelativeTo(null);
        
        // self mewakili instance home ini sendiri
        Home self = this;
        
        // memunculkan frame baru ketika mengklik salah satu data karyawan
        javax.swing.JTable tabelKaryawan = this.karyawanTable;
        tabelKaryawan.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int indexRowDipilih = tabelKaryawan.getSelectedRow();
                if (!e.getValueIsAdjusting() && indexRowDipilih >= 0) { // This line prevents double events
                    int idKaryawan = Integer.parseInt(tabelKaryawan.getValueAt(indexRowDipilih, 0).toString());
                    String namaLengkap = tabelKaryawan.getValueAt(indexRowDipilih, 1).toString();
                    String posisi = tabelKaryawan.getValueAt(indexRowDipilih, 2).toString();
                    
                    EditKaryawan editKaryawanFrame = new EditKaryawan(self, idKaryawan, namaLengkap, posisi);
                    editKaryawanFrame.setVisible(true);
                }
            }
        });
        
        // memunculkan frame baru ketika mengklik salah satu data pengajar
        javax.swing.JTable tabelPengajar = this.pengajarTable;
        tabelPengajar.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int indexRowDipilih = tabelPengajar.getSelectedRow();
                if (!e.getValueIsAdjusting() && indexRowDipilih >= 0) { // This line prevents double events
                    int idPengajar = Integer.parseInt(tabelPengajar.getValueAt(indexRowDipilih ,0).toString());
                    String nip = tabelPengajar.getValueAt(indexRowDipilih, 1).toString();
                    String namaLengkap = tabelPengajar.getValueAt(indexRowDipilih, 2).toString();
                    String mataKuliah = tabelPengajar.getValueAt(indexRowDipilih, 3).toString();
                    
                    EditPengajar editPengajarFrame = new EditPengajar(self, idPengajar, namaLengkap, nip, mataKuliah);
                    editPengajarFrame.setVisible(true);
                }
            }
        });
        
        // ambil data karyawan saat membuka aplikasi pertama kali
        this.ambilDataKaryawan();
        
        // ambil data karyawwan atau pengajar sesuai dengan tab yang dibuka
        this.homeTabbedPane.addChangeListener((e) -> {
            if (this.homeTabbedPane.getSelectedIndex() == 0) {
                this.ambilDataKaryawan();
            } else {
                this.ambilDataPengajar();
            }
        });
    }
    
    public void ambilDataKaryawan() {
        this.bersihkanTabelKaryawan();
        
        ArrayList<Karyawan> dataKaryawan = Karyawan.ambilSemua();
        for (Karyawan karyawan : dataKaryawan) {
            Object[] data = {
                karyawan.getId(),
                karyawan.getNamaLengkap(),
                karyawan.getPosisi(),
                Tanggal.konversiFormat(karyawan.getTanggalTerdaftar())
            };
            
            this.tambahDataTabel(this.karyawanTable, data);
        }
    }
    
    private void ambilDataKaryawan(String kataKunci) {
        this.bersihkanTabelKaryawan();
        
        ArrayList<Karyawan> dataKaryawan = Karyawan.ambilSemua(kataKunci);
        for (Karyawan karyawan : dataKaryawan) {
            Object[] data = {
                karyawan.getId(),
                karyawan.getNamaLengkap(),
                karyawan.getPosisi(),
                Tanggal.konversiFormat(karyawan.getTanggalTerdaftar())
            };
            this.tambahDataTabel(this.karyawanTable, data);
        }
    }
    
    public void ambilDataPengajar() {
        this.bersihkanTabelPengajar();
        
        ArrayList<Pengajar> dataPengajar = Pengajar.ambilSemua();
        for (Pengajar pengajar : dataPengajar) {
            Object[] data = {
                pengajar.getId(),
                pengajar.getNip(),
                pengajar.getNamaLengkap(),
                pengajar.getMataKuliah(),
                Tanggal.konversiFormat(pengajar.getTanggalTerdaftar())
            };
            
            this.tambahDataTabel(this.pengajarTable, data);
        }
    }
    
    public void ambilDataPengajar(String kataKunci) {
        this.bersihkanTabelPengajar();
        
        ArrayList<Pengajar> dataPengajar = Pengajar.ambilSemua(kataKunci);
        for (Pengajar pengajar : dataPengajar) {
            Object[] data = {
                pengajar.getId(),
                pengajar.getNip(),
                pengajar.getNamaLengkap(),
                pengajar.getMataKuliah(),
                Tanggal.konversiFormat(pengajar.getTanggalTerdaftar())
            };
            
            this.tambahDataTabel(this.pengajarTable, data);
        }
    }
    
    private void bersihkanTabelKaryawan() {
        DefaultTableModel tabel = (DefaultTableModel) this.karyawanTable.getModel();
        tabel.setRowCount(0);
    }
    
    private void bersihkanTabelPengajar() {
        DefaultTableModel tabel = (DefaultTableModel) this.pengajarTable.getModel();
        tabel.setRowCount(0);
    }
    
    // Overloading
    private void tambahDataTabel(javax.swing.JTable tabel, Object[] data) {
        DefaultTableModel model = (DefaultTableModel) tabel.getModel();
        model.addRow(data);
    }
    
    // Overloading
    private void tambahDataTabel(javax.swing.JTable tabel, Object[][] data) {
        DefaultTableModel model = (DefaultTableModel) tabel.getModel();
        for (Object[] d : data) {
            model.addRow(d);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        homeTabbedPane = new javax.swing.JTabbedPane();
        karyawanPanel = new javax.swing.JPanel();
        tambahDataKaryawanButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        karyawanTable = new javax.swing.JTable();
        cariKaryawanText = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        cariPengajarText = new javax.swing.JTextField();
        tambahDataPengajarButton = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        pengajarTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        homeTabbedPane.setBackground(new java.awt.Color(0, 0, 102));
        homeTabbedPane.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        homeTabbedPane.setForeground(new java.awt.Color(255, 255, 255));

        tambahDataKaryawanButton.setBackground(new java.awt.Color(0, 0, 102));
        tambahDataKaryawanButton.setForeground(new java.awt.Color(255, 255, 255));
        tambahDataKaryawanButton.setText("Tambah Data");
        tambahDataKaryawanButton.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        tambahDataKaryawanButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambahDataKaryawanButtonActionPerformed(evt);
            }
        });

        karyawanTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Nama Lengkap", "Posisi", "Tanggal Terdaftar"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(karyawanTable);

        cariKaryawanText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariKaryawanTextActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout karyawanPanelLayout = new javax.swing.GroupLayout(karyawanPanel);
        karyawanPanel.setLayout(karyawanPanelLayout);
        karyawanPanelLayout.setHorizontalGroup(
            karyawanPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(karyawanPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(karyawanPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(karyawanPanelLayout.createSequentialGroup()
                        .addComponent(cariKaryawanText, javax.swing.GroupLayout.PREFERRED_SIZE, 397, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(tambahDataKaryawanButton, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        karyawanPanelLayout.setVerticalGroup(
            karyawanPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(karyawanPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(karyawanPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tambahDataKaryawanButton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cariKaryawanText, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        homeTabbedPane.addTab("Karyawan", karyawanPanel);

        cariPengajarText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariPengajarTextActionPerformed(evt);
            }
        });

        tambahDataPengajarButton.setBackground(new java.awt.Color(0, 0, 102));
        tambahDataPengajarButton.setForeground(new java.awt.Color(255, 255, 255));
        tambahDataPengajarButton.setText("Tambah Data");
        tambahDataPengajarButton.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        tambahDataPengajarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambahDataPengajarButtonActionPerformed(evt);
            }
        });

        pengajarTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "NIP", "Nama Lengkap", "Mata Kuliah", "Tanggal Terdaftar"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(pengajarTable);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(cariPengajarText, javax.swing.GroupLayout.PREFERRED_SIZE, 397, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(tambahDataPengajarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tambahDataPengajarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cariPengajarText, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        homeTabbedPane.addTab("Pengajar", jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(homeTabbedPane, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 686, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(homeTabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 432, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tambahDataKaryawanButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambahDataKaryawanButtonActionPerformed
        TambahKaryawan tambahKaryawanFrame = new TambahKaryawan(this);
        tambahKaryawanFrame.setVisible(true);
    }//GEN-LAST:event_tambahDataKaryawanButtonActionPerformed

    private void tambahDataPengajarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambahDataPengajarButtonActionPerformed
        TambahPengajar tambahPengajarFrame = new TambahPengajar(this);
        tambahPengajarFrame.setVisible(true);
    }//GEN-LAST:event_tambahDataPengajarButtonActionPerformed

    private void cariPengajarTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariPengajarTextActionPerformed
        this.ambilDataPengajar(this.cariPengajarText.getText());
    }//GEN-LAST:event_cariPengajarTextActionPerformed

    private void cariKaryawanTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariKaryawanTextActionPerformed
        this.ambilDataKaryawan(this.cariKaryawanText.getText());
    }//GEN-LAST:event_cariKaryawanTextActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField cariKaryawanText;
    private javax.swing.JTextField cariPengajarText;
    private javax.swing.JTabbedPane homeTabbedPane;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel karyawanPanel;
    private javax.swing.JTable karyawanTable;
    private javax.swing.JTable pengajarTable;
    private javax.swing.JButton tambahDataKaryawanButton;
    private javax.swing.JButton tambahDataPengajarButton;
    // End of variables declaration//GEN-END:variables
}
