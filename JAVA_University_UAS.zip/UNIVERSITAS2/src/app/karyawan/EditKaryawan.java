package app.karyawan;

import app.Home;
import models.Karyawan;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

public class EditKaryawan extends javax.swing.JFrame {

    public EditKaryawan(Home homeFrame, int idKaryawan, String namaLengkap, String posisi) {
        initComponents();
        
        // arahkan frame ke tengah dan dengan fixed size
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        // dan dispose frame ini ketika di close
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        // set input value lama
        this.idKaryawan = idKaryawan;
        this.namaLengkapText.setText(namaLengkap);
        this.posisiComboBox.setSelectedItem(posisi);
        
        // ambil object frame home agar bisa menggunakan method ambilDataKaryawan
        this.homeFrame = homeFrame;
        
        this.namaLengkapText.addActionListener((e) -> this.editKaryawan());
        
        // menutup frame saat menekan tombol Esc
        this.setTutupFrameSaatEscape();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        namaLengkapLabel = new javax.swing.JLabel();
        namaLengkapText = new javax.swing.JTextField();
        posisiLabel = new javax.swing.JLabel();
        posisiComboBox = new javax.swing.JComboBox<>();
        editKaryawanButton = new javax.swing.JButton();
        hapusKaryawanButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        editKaryawanLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        namaLengkapLabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        namaLengkapLabel.setText("Nama Lengkap");

        namaLengkapText.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 153)));

        posisiLabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        posisiLabel.setText("Posisi");

        posisiComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Staff TU", "Keamanan" }));
        posisiComboBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 153)));

        editKaryawanButton.setBackground(new java.awt.Color(0, 0, 102));
        editKaryawanButton.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        editKaryawanButton.setForeground(new java.awt.Color(255, 255, 255));
        editKaryawanButton.setText("Edit");
        editKaryawanButton.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        editKaryawanButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editKaryawanButtonActionPerformed(evt);
            }
        });

        hapusKaryawanButton.setBackground(new java.awt.Color(204, 0, 0));
        hapusKaryawanButton.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        hapusKaryawanButton.setForeground(new java.awt.Color(255, 255, 255));
        hapusKaryawanButton.setText("Hapus");
        hapusKaryawanButton.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        hapusKaryawanButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusKaryawanButtonActionPerformed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/app/1111.png"))); // NOI18N
        jLabel2.setText("jLabel2");

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/app/111.png"))); // NOI18N
        jLabel4.setText("jLabel4");

        editKaryawanLabel.setBackground(new java.awt.Color(0, 102, 153));
        editKaryawanLabel.setFont(new java.awt.Font("Cambria", 1, 24)); // NOI18N
        editKaryawanLabel.setForeground(new java.awt.Color(0, 0, 102));
        editKaryawanLabel.setText("EDIT KARYAWAN");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/app/pengajar/output-onlinepngtools.png"))); // NOI18N
        jLabel1.setText("jLabel1");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                .addGap(37, 37, 37)
                .addComponent(editKaryawanLabel)
                .addGap(79, 79, 79)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(namaLengkapLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 374, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(namaLengkapText, javax.swing.GroupLayout.PREFERRED_SIZE, 412, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(posisiLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 399, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(hapusKaryawanButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(editKaryawanButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(posisiComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 414, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(65, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(editKaryawanLabel)
                        .addGap(42, 42, 42))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(19, 19, 19)))
                .addComponent(namaLengkapLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(namaLengkapText, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(posisiLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(posisiComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(hapusKaryawanButton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(editKaryawanButton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void editKaryawanButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editKaryawanButtonActionPerformed
        this.editKaryawan();
    }//GEN-LAST:event_editKaryawanButtonActionPerformed

    private void editKaryawan() {
        String namaLengkap = this.namaLengkapText.getText();
        String posisi = this.posisiComboBox.getSelectedItem().toString();
        
        Karyawan karyawan = new Karyawan();
        karyawan.setId(this.idKaryawan);
        karyawan.setNamaLengkap(namaLengkap);
        karyawan.setPosisi(posisi);
        
        if (karyawan.ubah()) {
            JOptionPane.showMessageDialog(null, "Berhasil mengedit data karyawan");
            this.homeFrame.ambilDataKaryawan();
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(null, "Telah terjadi kesalahan, silakan coba lagi");
        }
    }
    
    private void hapusKaryawanButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusKaryawanButtonActionPerformed
        int konfirmasi = JOptionPane.showConfirmDialog(null, "Apakah anda yakin ingin menghapus data ini?");
        if (konfirmasi == 0) {
            Karyawan karyawan = new Karyawan();
            karyawan.setId(this.idKaryawan);
            
            if (karyawan.hapus()) {
                JOptionPane.showMessageDialog(null, "Berhasil menghapus data karyawan");
                this.homeFrame.ambilDataKaryawan();
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(null, "Telah terjadi kesalahan, silakan coba lagi");
            }
        }
    }//GEN-LAST:event_hapusKaryawanButtonActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditKaryawan(new Home(), 0, "", "").setVisible(true);
            }
        });
    }
    
    // menutup frame saat menekan tombol Esc
    private void setTutupFrameSaatEscape() {
        this.getRootPane()
            .getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
            .put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "Cancel");
        
        EditKaryawan self = this;
        this.getRootPane().getActionMap().put("Cancel", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                self.setVisible(false);
                self.dispose();
            }
        });
    }
    
    private int idKaryawan;
    private Home homeFrame;

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton editKaryawanButton;
    private javax.swing.JLabel editKaryawanLabel;
    private javax.swing.JButton hapusKaryawanButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel namaLengkapLabel;
    private javax.swing.JTextField namaLengkapText;
    private javax.swing.JComboBox<String> posisiComboBox;
    private javax.swing.JLabel posisiLabel;
    // End of variables declaration//GEN-END:variables
}
