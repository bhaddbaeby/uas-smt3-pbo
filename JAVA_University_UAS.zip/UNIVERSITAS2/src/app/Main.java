package app;

public class Main {

    public static void main(String[] args) {
        Login app = new Login();
        app.setVisible(true);
    }
    
}
