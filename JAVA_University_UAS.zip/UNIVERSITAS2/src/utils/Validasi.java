package utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

// abstract class untuk yang membutuhkan validasi
// dalam aplikasi ini yang butuh validasi yaitu: login
public abstract class Validasi extends javax.swing.JFrame {
    // regex untuk validasi email
    public static final Pattern VALID_EMAIL_ADDRESS_REGEX = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
    
    public boolean validasiEmail(String emailStr) {
        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(emailStr);
        return matcher.find();
    }
    
    public void showMessage(String message) {
        JOptionPane.showMessageDialog(null, message);
    }
    
    // setiap class yang mewarisi class ini harus punya method validasi ini
    // contohnya ada di class Login
    abstract public boolean validasi();
}
